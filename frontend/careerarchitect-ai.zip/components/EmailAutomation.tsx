import React, { useState } from 'react';
import { Mail, Search, UserPlus, Send, ArrowUpRight } from 'lucide-react';
import { ResumeData, Lead } from '../types';
import { generateColdEmailAI } from '../services/gemini';

interface EmailAutomationProps {
  resumeData: ResumeData | null;
}

const MOCK_LEADS: Lead[] = [
  { id: '1', name: 'Sarah Miller', company: 'TechFlow Inc.', role: 'VP of Engineering', email: 'sarah@techflow.io' },
  { id: '2', name: 'David Chen', company: 'DataSphere', role: 'CTO', email: 'david@datasphere.ai' },
  { id: '3', name: 'Jessica Davis', company: 'CloudScale', role: 'Head of Product', email: 'jessica@cloudscale.net' },
  { id: '4', name: 'Michael Ross', company: 'FinTech Solutions', role: 'Talent Acquisition', email: 'mike@fintech.co' },
];

const EmailAutomation: React.FC<EmailAutomationProps> = ({ resumeData }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [generatedEmail, setGeneratedEmail] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const filteredLeads = MOCK_LEADS.filter(l => 
    l.company.toLowerCase().includes(searchTerm.toLowerCase()) || 
    l.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleGenerate = async (lead: Lead) => {
    if (!resumeData) return;
    setSelectedLead(lead);
    setIsGenerating(true);
    setGeneratedEmail('');
    
    try {
      const email = await generateColdEmailAI(resumeData, lead.name, lead.company, lead.role);
      setGeneratedEmail(email);
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  if (!resumeData) {
    return (
      <div className="text-center py-20 bg-white rounded-xl border border-dashed border-slate-300">
        <Mail className="mx-auto text-slate-300 mb-4" size={48} />
        <h3 className="text-lg font-medium text-slate-900">Resume Data Missing</h3>
        <p className="text-slate-500 mt-1">Please process your resume in the Resume Builder first.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end">
        <div>
            <h2 className="text-2xl font-bold text-slate-900">Apollo Email Automation</h2>
            <p className="text-slate-500 mt-1">Find leads and generate hyper-personalized cold outreach.</p>
        </div>
        <div className="hidden md:flex space-x-2">
            <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium flex items-center">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                Email Sequencer Active
            </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
        {/* Search Panel */}
        <div className="lg:col-span-1 bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden">
          <div className="p-4 border-b border-slate-100">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={16} />
              <input 
                type="text" 
                placeholder="Search companies or people..." 
                className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-2">
            {filteredLeads.map(lead => (
              <div 
                key={lead.id} 
                onClick={() => handleGenerate(lead)}
                className={`p-3 rounded-lg cursor-pointer transition-colors border ${selectedLead?.id === lead.id ? 'bg-indigo-50 border-indigo-200' : 'bg-white border-transparent hover:bg-slate-50'}`}
              >
                <div className="flex justify-between items-start">
                    <h4 className="font-semibold text-slate-900 text-sm">{lead.name}</h4>
                    {selectedLead?.id === lead.id && isGenerating && <div className="animate-pulse w-2 h-2 bg-indigo-500 rounded-full"></div>}
                </div>
                <p className="text-xs text-slate-500">{lead.role}</p>
                <p className="text-xs text-indigo-600 font-medium mt-1">{lead.company}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Editor Panel */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col">
          {selectedLead ? (
            <>
                <div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                    <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs">
                            {selectedLead.name.charAt(0)}
                        </div>
                        <div>
                            <p className="text-sm font-medium text-slate-900">To: {selectedLead.name} <span className="text-slate-400 font-normal">&lt;{selectedLead.email}&gt;</span></p>
                        </div>
                    </div>
                    <button className="text-xs text-indigo-600 hover:underline flex items-center">
                        View LinkedIn <ArrowUpRight size={12} className="ml-1"/>
                    </button>
                </div>
                
                <div className="flex-1 p-6 relative">
                    {isGenerating ? (
                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/80 z-10">
                            <Loader2 className="animate-spin text-indigo-600 mb-2" size={32} />
                            <p className="text-sm text-slate-600">Analyzing prospect & drafting email...</p>
                        </div>
                    ) : null}
                    
                    <textarea 
                        className="w-full h-full resize-none focus:outline-none text-slate-800 text-sm leading-relaxed"
                        value={generatedEmail}
                        onChange={(e) => setGeneratedEmail(e.target.value)}
                        placeholder="Select a lead to generate a draft..."
                    ></textarea>
                </div>

                <div className="p-4 border-t border-slate-100 flex justify-end space-x-3 bg-slate-50">
                    <button className="px-4 py-2 border border-slate-300 rounded-lg text-sm text-slate-600 font-medium hover:bg-slate-100">Save Draft</button>
                    <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 flex items-center">
                        <Send size={16} className="mr-2" /> Send via Gmail
                    </button>
                </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
                <UserPlus size={48} className="mb-4 opacity-20" />
                <p>Select a lead to start outreach</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const Loader2 = ({ className, size }: { className?: string, size?: number }) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width={size} 
        height={size} 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        className={className}
    >
        <path d="M21 12a9 9 0 1 1-6.219-8.56" />
    </svg>
);

export default EmailAutomation;
