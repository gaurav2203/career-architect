import React, { useState } from 'react';
import { Layout, Palette, Code, Loader2, ExternalLink } from 'lucide-react';
import { ResumeData } from '../types';
import { generatePortfolioContentAI } from '../services/gemini';

interface PortfolioGeneratorProps {
  resumeData: ResumeData | null;
}

const PortfolioGenerator: React.FC<PortfolioGeneratorProps> = ({ resumeData }) => {
  const [theme, setTheme] = useState('modern-minimal');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState<any>(null);

  const handleGenerate = async () => {
    if (!resumeData) return;
    setIsGenerating(true);
    try {
      const content = await generatePortfolioContentAI(resumeData, theme);
      setGeneratedContent(content);
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  if (!resumeData) {
    return (
      <div className="text-center py-20 bg-white rounded-xl border border-dashed border-slate-300">
        <Layout className="mx-auto text-slate-300 mb-4" size={48} />
        <h3 className="text-lg font-medium text-slate-900">Resume Data Missing</h3>
        <p className="text-slate-500 mt-1">Please process your resume in the Resume Builder first.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Portfolio Generator</h2>
        <p className="text-slate-500 mt-1">Turn your resume into a stunning Next.js portfolio website in seconds.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Configuration Panel */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h3 className="font-semibold text-slate-900 mb-4 flex items-center">
              <Palette className="mr-2 text-indigo-600" size={18} /> Theme Selection
            </h3>
            
            <div className="space-y-3">
              {[
                { id: 'modern-minimal', name: 'Modern Minimal', desc: 'Clean, typography-focused' },
                { id: 'creative-bold', name: 'Creative Bold', desc: 'High contrast, large imagery' },
                { id: 'dev-terminal', name: 'Dev Terminal', desc: 'Dark mode, monospace fonts' },
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTheme(t.id)}
                  className={`w-full text-left p-3 rounded-lg border transition-all ${
                    theme === t.id
                      ? 'border-indigo-600 bg-indigo-50 ring-1 ring-indigo-600'
                      : 'border-slate-200 hover:border-indigo-300'
                  }`}
                >
                  <div className="font-medium text-slate-900 text-sm">{t.name}</div>
                  <div className="text-xs text-slate-500">{t.desc}</div>
                </button>
              ))}
            </div>

            <div className="mt-6 pt-6 border-t border-slate-100">
              <div className="flex items-center justify-between text-sm text-slate-600 mb-4">
                <span>Projects to include</span>
                <span className="font-medium text-slate-900">Auto-select Top 2</span>
              </div>
              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="w-full bg-indigo-600 text-white py-3 rounded-lg font-medium hover:bg-indigo-700 transition-colors flex items-center justify-center"
              >
                {isGenerating ? <Loader2 className="animate-spin mr-2" size={18} /> : <Code className="mr-2" size={18} />}
                Generate Portfolio
              </button>
            </div>
          </div>
        </div>

        {/* Preview Panel */}
        <div className="lg:col-span-2">
          {generatedContent ? (
            <div className="bg-slate-900 rounded-xl overflow-hidden shadow-2xl ring-1 ring-slate-900/10">
              <div className="bg-slate-800 p-3 flex items-center space-x-2">
                <div className="flex space-x-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                </div>
                <div className="flex-1 bg-slate-900 rounded px-3 py-1 text-xs text-slate-400 font-mono text-center">
                  localhost:3000
                </div>
              </div>
              <div className="bg-white min-h-[500px] p-8 md:p-12 overflow-y-auto max-h-[600px]">
                {/* Mock Portfolio View */}
                <header className="mb-16">
                    <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight mb-4">
                        {generatedContent.heroHeadline || "Building Digital Products"}
                    </h1>
                    <p className="text-xl text-slate-600 max-w-2xl leading-relaxed">
                        {generatedContent.heroSubtext || "I craft accessible, pixel-perfect user experiences."}
                    </p>
                    <div className="mt-8 flex gap-4">
                        <button className="bg-black text-white px-6 py-3 rounded-full font-medium text-sm">View Work</button>
                        <button className="bg-slate-100 text-slate-900 px-6 py-3 rounded-full font-medium text-sm">Contact Me</button>
                    </div>
                </header>

                <section className="mb-16">
                    <h2 className="text-sm font-bold uppercase tracking-widest text-slate-400 mb-6">Selected Work</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {(generatedContent.projectsHighlighted || []).map((p: any, i: number) => (
                            <div key={i} className="group cursor-pointer">
                                <div className="aspect-video bg-slate-100 rounded-xl mb-4 group-hover:bg-slate-200 transition-colors"></div>
                                <h3 className="font-bold text-lg text-slate-900 group-hover:text-indigo-600 transition-colors">{p.name}</h3>
                                <p className="text-slate-500 text-sm mt-1">{p.description}</p>
                            </div>
                        ))}
                    </div>
                </section>

                <section className="bg-slate-50 -mx-8 md:-mx-12 px-8 md:px-12 py-16">
                    <h2 className="text-sm font-bold uppercase tracking-widest text-slate-400 mb-6">About</h2>
                    <p className="text-slate-700 leading-loose max-w-3xl">
                        {generatedContent.aboutSection || resumeData.summary}
                    </p>
                </section>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[400px] bg-slate-100 rounded-xl border-2 border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400">
                <Layout size={64} className="mb-4 opacity-50" />
                <p>Preview will appear here after generation</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PortfolioGenerator;
