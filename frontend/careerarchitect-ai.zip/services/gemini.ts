import { GoogleGenAI, Type } from "@google/genai";
import { ResumeData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = "gemini-2.5-flash";

const sanitizeResumeData = (data: any): ResumeData => {
  return {
    personalInfo: {
      name: data.personalInfo?.name || "",
      email: data.personalInfo?.email || "",
      phone: data.personalInfo?.phone || "",
      linkedin: data.personalInfo?.linkedin || "",
      github: data.personalInfo?.github || "",
      website: data.personalInfo?.website || "",
    },
    summary: data.summary || "",
    skills: Array.isArray(data.skills) ? data.skills : [],
    experience: Array.isArray(data.experience) ? data.experience.map((e: any) => ({
      role: e.role || "",
      company: e.company || "",
      duration: e.duration || "",
      details: Array.isArray(e.details) ? e.details : (typeof e.details === 'string' ? [e.details] : []),
    })) : [],
    education: Array.isArray(data.education) ? data.education.map((e: any) => ({
      degree: e.degree || "",
      school: e.school || "",
      year: e.year || "",
    })) : [],
    projects: Array.isArray(data.projects) ? data.projects.map((p: any) => ({
      name: p.name || "",
      description: p.description || "",
      tech: Array.isArray(p.tech) ? p.tech : [],
    })) : [],
  };
};

export const parseResumeAI = async (base64Data: string, mimeType: string): Promise<ResumeData> => {
  const prompt = `
    Analyze the attached resume and extract structured data.
    Return a JSON object with: 
    - personalInfo (name, email, phone, linkedin, github, website)
    - summary
    - skills (array of strings)
    - experience (array of objects with role, company, duration, details)
    - education (array of objects with degree, school, year)
    - projects (array of objects with name, description, tech)
    
    Ensure 'details' in experience is an array of strings (bullet points).
    Ensure 'tech' in projects is an array of strings.
    If a personal info field is not found, return an empty string.
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: [
        {
          parts: [
            {
              inlineData: {
                mimeType: mimeType,
                data: base64Data
              }
            },
            { text: prompt }
          ]
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            personalInfo: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                email: { type: Type.STRING },
                phone: { type: Type.STRING },
                linkedin: { type: Type.STRING },
                github: { type: Type.STRING },
                website: { type: Type.STRING },
              },
            },
            summary: { type: Type.STRING },
            skills: { type: Type.ARRAY, items: { type: Type.STRING } },
            experience: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  role: { type: Type.STRING },
                  company: { type: Type.STRING },
                  duration: { type: Type.STRING },
                  details: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
              },
            },
            education: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  degree: { type: Type.STRING },
                  school: { type: Type.STRING },
                  year: { type: Type.STRING },
                },
              },
            },
            projects: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  description: { type: Type.STRING },
                  tech: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
              },
            },
          },
        },
      },
    });

    if (response.text) {
      try {
        const rawData = JSON.parse(response.text);
        return sanitizeResumeData(rawData);
      } catch (e) {
        console.error("Failed to parse JSON response:", response.text);
        throw new Error("AI returned invalid JSON.");
      }
    }
    
    // Check if safety blocked the response
    if (response.candidates?.[0]?.finishReason) {
        throw new Error(`AI generation stopped: ${response.candidates[0].finishReason}`);
    }

    throw new Error("No data returned from AI");
  } catch (error) {
    console.error("Error parsing resume:", error);
    throw error;
  }
};

export const generateCoverLetterAI = async (resume: ResumeData, jobDesc: string): Promise<string> => {
  const prompt = `
    You are an expert career coach. Write a professional, compelling cover letter based on the candidate's resume and the job description.
    
    Candidate Name: ${resume.personalInfo?.name || "Candidate"}
    Candidate Resume Summary: ${resume.summary}
    Candidate Skills: ${resume.skills.join(", ")}
    Candidate Experience: ${resume.experience.map(e => `${e.role} at ${e.company}`).join("; ")}
    
    Job Description:
    ${jobDesc}
    
    Keep it concise, professional, and tailored to the role.
  `;

  const response = await ai.models.generateContent({
    model: MODEL_NAME,
    contents: prompt,
  });

  return response.text || "Failed to generate cover letter.";
};

export const generateColdEmailAI = async (resume: ResumeData, leadName: string, company: string, role: string): Promise<string> => {
  const prompt = `
    Write a high-converting cold email (Apollo style) to ${leadName}, who is a ${role} at ${company}.
    The sender is ${resume.personalInfo?.name || "a candidate"} with the following background:
    Summary: ${resume.summary}
    Top Skills: ${resume.skills.slice(0, 5).join(", ")}
    
    The goal is to get a 15-minute chat about potential opportunities. Keep it short (under 150 words), personalized, and value-driven.
  `;

  const response = await ai.models.generateContent({
    model: MODEL_NAME,
    contents: prompt,
  });

  return response.text || "Failed to generate email.";
};

export const generatePortfolioContentAI = async (resume: ResumeData, theme: string): Promise<any> => {
  const prompt = `
    Generate content for a personal portfolio website with a "${theme}" theme.
    Use this resume data:
    ${JSON.stringify(resume)}
    
    Return a JSON object with:
    - heroHeadline (punchy one-liner)
    - heroSubtext (short bio)
    - aboutSection (detailed bio)
    - projectsHighlighted (select top 2 projects)
  `;

  const response = await ai.models.generateContent({
    model: MODEL_NAME,
    contents: prompt,
    config: {
        responseMimeType: "application/json"
    }
  });

    if (response.text) {
      return JSON.parse(response.text);
    }
    return {};
};
