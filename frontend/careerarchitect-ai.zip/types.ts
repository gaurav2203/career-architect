export interface ResumeData {
  personalInfo: {
    name: string;
    email: string;
    phone: string;
    linkedin: string;
    github: string;
    website: string;
  };
  summary: string;
  skills: string[];
  experience: {
    role: string;
    company: string;
    duration: string;
    details: string[];
  }[];
  education: {
    degree: string;
    school: string;
    year: string;
  }[];
  projects: {
    name: string;
    description: string;
    tech: string[];
  }[];
}

export interface UserProfile {
  name: string;
  email: string;
  resumeData: ResumeData | null;
  rawResumeText: string;
}

export interface JobDescription {
  company: string;
  role: string;
  description: string;
}

export interface Lead {
  id: string;
  name: string;
  company: string;
  role: string;
  email: string;
}

export enum AppRoute {
  DASHBOARD = 'dashboard',
  RESUME = 'resume',
  PORTFOLIO = 'portfolio',
  COVER_LETTER = 'cover-letter',
  EMAIL = 'email',
}
